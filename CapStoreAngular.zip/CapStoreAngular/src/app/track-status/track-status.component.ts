import { Component, OnInit, ViewChild } from '@angular/core';
import { MatStepper, MatVerticalStepper } from '@angular/material/stepper';
import { interval } from 'rxjs';
import { throwMatDialogContentAlreadyAttachedError } from '@angular/material';
@Component({
  selector: 'app-track-status',
  templateUrl: './track-status.component.html',
  styleUrls: ['./track-status.component.css']
})
export class TrackStatusComponent implements OnInit {
  @ViewChild('stepper') stepper: MatVerticalStepper;
  constructor() { }

  // current date is set and increament by 1
  today = new Date();
  date1 = new Date();
  date2 = new Date();
  date3 = new Date();

  ngOnInit() {
    this.date1.setDate(this.today.getDate() + 1);
    this.date2.setDate(this.today.getDate() + 2);
    this.date3.setDate(this.today.getDate() + 3);
    setInterval(() => {
      this.changeStep();
  }, 4000);
  }

  changeStep() {
    this.stepper.next();
  }
}
