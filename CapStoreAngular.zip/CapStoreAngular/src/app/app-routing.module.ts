import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TrackStatusComponent } from './track-status/track-status.component';


const routes: Routes = [
  { path: '', redirectTo: '/statusTrack', pathMatch: 'full' },
  { path: 'statusTrack', component: TrackStatusComponent},
  { path: '**', redirectTo: '/statusTrack', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
