import { NgModule } from '@angular/core';
import {  MatButtonModule } from '@angular/material';
import {CdkStepperModule} from '@angular/cdk/stepper';
// import { MatStepper } from '@angular/material/stepper';
import { MatStepperModule } from '@angular/material';
import {MatIconModule} from '@angular/material/icon';

@NgModule({
  imports: [
    MatButtonModule,
    CdkStepperModule,
    MatStepperModule,
    MatIconModule

  ],
  exports: [
    MatButtonModule,
    CdkStepperModule,
    MatStepperModule,
    MatIconModule
  ]
})
export class MaterialModule { }
