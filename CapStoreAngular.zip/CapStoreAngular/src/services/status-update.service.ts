import { Injectable } from '@angular/core';
import {take} from 'rxjs/operators';
import { timer } from 'rxjs';
// import { OrderInfo } from 'src/app/model/OrderInfo.1';

@Injectable({
  providedIn: 'root'
})

export class StatusUpdateService {
 // dummyData: OrderInfo;

  constructor() {
    // set dummy product info
    // this.dummyData = new OrderInfo();
    // this.dummyData.productId = 'ADF78941230';
    // this.dummyData.productName = 'Yamaha R15';
    // this.dummyData.deliveryStatus = 'Your order is placed successfully';
  }
}
