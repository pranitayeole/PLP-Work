export class OrderInfo {
    orderId: number;
    productId: string;
    productName: string;
    deliveryStatus: string;
}
